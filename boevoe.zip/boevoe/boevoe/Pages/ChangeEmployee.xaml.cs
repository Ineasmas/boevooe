﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using boevoe.Entities;
namespace boevoe.Pages
{
    /// <summary>
    /// Логика взаимодействия для ChangeEmployee.xaml
    /// </summary>
    public partial class ChangeEmployee : Page
    {
        Entities.boevoeEntities db = boevoeEntities.GetContext();
        Employees employee;
        public ChangeEmployee(int idSelected)
        {
            InitializeComponent();
            employee = db.Employees.Where(a => a.idEmployee == idSelected).FirstOrDefault();
            if(idSelected!=1923924)
            {
                NameBox.Text = employee.FirstName;
                LastNameBox.Text = employee.LastName;
                BirthDateBox.Text = employee.BirthDate;
                AddressBox.Text = employee.Address;
                EmployeeTypeBox.Text = employee.idEmployeeType.ToString();
                LoginBox.Text = employee.Login;
                PasswordBox.Text = employee.Password;
            }
            
        }

        private void CancelBtn_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Admin(null));
        }
       

        private void AccBtn_Click(object sender, RoutedEventArgs e)
        {
            //try
            //{
            //    Entities.boevoeEntities db = boevoeEntities.GetContext();
            //    Employees employees = new Employees();
            //    employees.FirstName = NameBox.Text.Trim();
            //    employees.LastName = LastNameBox.Text.Trim();
            //    employees.BirthDate = BirthDateBox.Text.Trim();
            //    employees.Address = AddressBox.Text.Trim();
            //    employees.idEmployeeType =int.Parse(EmployeeTypeBox.Text.Trim());
            //    employees.Login = LoginBox.Text.Trim();
            //    employees.Password = PasswordBox.Text.Trim();
            //    db.Employees.Add(employees);
            //    db.SaveChanges();
            //    MessageBox.Show("Успешно сохранено!");
            //    NavigationService.Navigate(new Admin(null));
            //}
            //catch
            //{
            //    MessageBox.Show("Ошибка при заполнении данных");
            //}
        }
    }
}
