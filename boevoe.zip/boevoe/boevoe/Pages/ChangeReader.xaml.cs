﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using boevoe.Entities;
namespace boevoe.Pages
{
    /// <summary>
    /// Логика взаимодействия для ChangeReader.xaml
    /// </summary>
    public partial class ChangeReader : Page
    {
        Entities.boevoeEntities db = boevoeEntities.GetContext();
        Readers reader;
        public ChangeReader(int idSelected)
        {
            InitializeComponent();
            reader = db.Readers.Where(a => a.idReader == idSelected).FirstOrDefault();
            if (idSelected != -1)
            {
                NameBox.Text = reader.FirstName;
                LastNameBox.Text = reader.LastName;
                BirthDateBox.Text = reader.BirthDate;
                AddressBox.Text = reader.Address;
                PhoneNumberBox.Text = reader.PhoneNumber;
            }
        }

        private void CancelBtn_Click(object sender, RoutedEventArgs e)
        {

        }

        private void AccBtn_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
