﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using boevoe.Entities;
namespace boevoe.Pages
{
    /// <summary>
    /// Логика взаимодействия для Auth.xaml
    /// </summary>
    public partial class Authorization : Page
    {
        public Authorization()
        {
            InitializeComponent();
        }

        private void btEnter_Click(object sender, RoutedEventArgs e)
        {
            string login = LoginBox.Text.Trim();
            string password = PasswordBox.Password.Trim();
            Employees employee = new Employees();
            try
            {


                employee = boevoeEntities.GetContext().Employees.Where(p => p.Login == login && p.Password == password).FirstOrDefault();
                if (employee != null)
                {
                    MessageBox.Show("Вы вошли под: " + employee.EmployeeTypes.Name.ToString());
                    LoadForm(employee.EmployeeTypes.Name.ToString(), employee);
                }

            }
            catch
            {
                MessageBox.Show("ошибка");
            }
        }
        private void btCancel_Click(object sender, RoutedEventArgs e)
        {
            
        }
        private void LoadForm(string _role, Employees employee)
        {
            switch (_role)
            {
                
                case "Администратор":
                    NavigationService.Navigate(new Admin(employee));
                    break;
                case "Глбиблиотекарь":
                    NavigationService.Navigate(new MainLibrarian(employee));
                    break;
                case "Библиотекарь":
                    NavigationService.Navigate(new Librarian(employee));
                    break;
            }
        }
    }
}
